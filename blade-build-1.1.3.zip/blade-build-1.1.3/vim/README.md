# vim-typhoon-blade

---

Separate vim syntax plugin [vim-typhoon-blade](https://github.com/hiberabyss/vim-typhoon-blade)
could be installed via vundle or vim-plug.

## Installation

### vundle

Add to vimrc file:

    Bundle 'zhangyafeikimi/vim-typhoon-blade'

### Manual installation

Copy all files to vim plugin directory($HOME/.vim, vimfiles, $VIMRUNTIME, ...).
