void yyparse();

int main(void) {
    yyparse();
    return 0;
}

