#include "extra.h"

#include <iostream>
#include "common/common.h"
#include "extra_extra.h"

void Extra() {
	Common();
	std::cout << "Extra" << "\n";
	ExtraExtra();
}
