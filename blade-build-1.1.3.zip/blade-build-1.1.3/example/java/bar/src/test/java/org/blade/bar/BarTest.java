package org.blade.bar;

import org.junit.Test;

public class BarTest {
    @Test
    void testBar() {
        Bar bar = new Bar();
    }
}
