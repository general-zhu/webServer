package org.blade.bar;

import org.blade.foo.Foo;

public class Bar extends Foo {
    public static void main(String[] args) {
        System.out.println("hello, world!");
    }
}
