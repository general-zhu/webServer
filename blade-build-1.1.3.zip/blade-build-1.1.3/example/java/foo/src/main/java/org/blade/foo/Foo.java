package org.blade.foo;

import com.qq.blade.examples.ContactProto;

// class Nested { }

public class Foo {
    public class Inner { }
}
