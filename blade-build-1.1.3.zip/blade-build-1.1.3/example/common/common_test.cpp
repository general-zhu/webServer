#include "common/common.h"
#include "thirdparty/gtest/gtest.h"

int main() {
    return 0;
}
