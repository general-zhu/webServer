#ifndef COMMON_COMMON_H
#define COMMON_COMMON_H
#pragma once

void Common();

#endif // COMMON_COMMON_H
