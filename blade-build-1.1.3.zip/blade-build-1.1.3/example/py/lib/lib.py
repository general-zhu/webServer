import py.proto.address_book_pb2

def NewAddressBook():
    return py.proto.address_book_pb2.AddressBook()

