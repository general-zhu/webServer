extern void asm1();
extern void asm2();

int main() {
    asm1();
    asm2();
    return 0;
}
