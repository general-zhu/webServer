#include "gen_rule/header.h"

int main() {
    return 0;
}
