# See http://google-perftools.googlecode.com/svn/trunk/doc/heap_checker.html
HEAP_CHECK_VALUES = set([
    '',
    'minimal',
    'normal',
    'strict',
    'draconian',
    'as-is',
    'local',
])
